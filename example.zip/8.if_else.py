# If else Condition

number = 10

if number > 0:
    print('Positive number')
else:
    print('Negative number')
    
# ex not in if else bloc 
print('This statement is always executed')