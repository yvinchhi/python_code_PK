# 1. Write a program to print the message
# "Welcome to Python Class".
print("Welcome to python class..")
print(5+5)
a=20
print(a)
print("Value of A : ",a)

# 2. Create a program to display a static 
# variable with a value of 100.
# type() is used to print data type of variable
# static variable

# static variable
name="parul"
age=25
b=5.5
print(type(name))
print(type(age))
print(type(b))

# 3. Write a Python program that asks 
# the user for their name and age, 

name= input("Enter Your Name :")
print("your name is...",name)
print(type(name))

age = int(input("enter your age :"))
print("your age is..",age)
print(type(age))

