name=input("Enter your name:")
print(" your name is:",name)

age= int(input("enter yor age"))
print("your age is..",age)