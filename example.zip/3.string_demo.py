# Write a program to demonstrate the three ways 
# of defining strings in Python 
# (single quotes, double quotes, triple quotes).

# 3 ways to decalare Sring in python

# 1. Using Single Quotes

name1 = 'Welcome to Python Class'
print('Single Quotes :', name1)

# 2. Using double Quotes

name2 = "Welcome to Asp.Class"
print('double Quotes :', name2)

# 3. Using tripple Quotes

name3 = '''Welcome to Flutter Class'''
print('triple Quotes :', name3)

# Multiline String   
name4 = """ Hello , Good Morning....
            Students..."""

print('Multiline String :', name4)

# three time ''' & """ use for 
# declare multiline string
# and multiline comments