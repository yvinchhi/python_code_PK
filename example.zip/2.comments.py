# 4. Add single-line and multi-line comments to a 
# program explaining how it works.
# 5 . Create a program with a multiline string
# that says:
	   # "Hello Students,
       #  Welcome to Python Learning!"

#types of comments in python

# 1. Single Line
# 2. Multi Line or String Comment

# it is name variable for store name value
name="parul"

""" it is used 
to multiline comments 
as well as multiline string declarations...
"""
# example for store address value
add="""asdasd
asdad
assdasda
asdad
"""
print(add)

address= '''adsdas
asdasd
asdasda
asdas'''
