# different types of varibale declartion with values

name = "A"  
Name = "B"  
naMe = "C"  
NAME = "D"  
n_a_m_e = "E"  
_name = "F"  
name_ = "G"  
_name_ = "H"  
na8me = "I"  
  
print(name,Name,naMe,NAME,n_a_m_e, NAME, n_a_m_e, _name, name_,_name, na8me)  

#Assign the same value 50 to three 
# variables (a, b, c) and print their values.

a=b=c=50
print(a)

# multiple assignments
a=b=c=50

print('Value of A :' , a)
print('Value of B :' , b)
print('Value of C :' , c)

# Assign values 10, 20, 30 to 
# three variables (x, y, z) in a single line 
# and display their values.

x,y,z=10,20,30

print('Values of X :' , x)
print('Values of Y :' , y)
print('Values of Z :' , z)
     

