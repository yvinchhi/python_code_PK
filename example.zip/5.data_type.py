# Write a program to demonstrate the use of int and float by 
# taking user input for both types and printing their sum.


# Number Data type example
a1=5
a = int(input('Enter Value of A:'))
print("The type of a", type(a))  
  
b1=10.5  
b = float(input('Enter value of B:'))
print("The type of b", type(b))  


# String Data type Example -1 

str = "string example using double quotes"  
print('String Value : ' , str)  

s = ''' A multiline 
string example '''  

print(s)   



"""Create a string variable and print: 
Its entire content.
Its first and last characters using slicing.
"""

# String Example-2

str1 = 'hello students' #string str1    
str2 = ' how are you ?' #string str2    
print (str1[0:2]) #printing first two character using slice operator    
print (str1[4]) #printing 4th character of the string    
print (str1*2) #printing the string twice    
print (str1 + str2) #printing the concatenation of str1 and str2 


# Write a program to show examples of Boolean types (True and False).

print(type(False))   
 