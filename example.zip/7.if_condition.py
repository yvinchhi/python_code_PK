# If Condition

number = 10

# check if number is greater than 0
if number > 0:
    print('Number is positive.')




