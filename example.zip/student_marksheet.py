"""stud  ent name
enroll num
subject 1 mark
subject 2 mark
subject 3 mark
subject 4 mark
Grade"""